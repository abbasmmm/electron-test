const path = require('path');

module.exports = {
  entry: './e2e/index.ts',  // Entry file for your project
  output: {
    filename: 'index.js',  // Output file name
    path: path.resolve(__dirname, 'dist'),  // Output directory
    library: {
      type: 'commonjs2',  // Ensure CommonJS format for Node.js compatibility
    },
    clean: true,  // Clean the output directory before each build (optional)
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,  // Match .ts and .tsx files
        use: 'ts-loader',  // Use ts-loader for TypeScript files
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: ['.ts', '.tsx', '.js'],  // Resolve these extensions
  },
  externals: {
    // External dependencies can be added here if needed
  },
  target: 'node',  // Target Node.js environment
};
