import path from 'path';
import { TestWorld } from '../world';

let customMethods;
let methodNames;

export const LoadScript = () => {
    const filePath = path.join(__dirname, '..', '..', 'dist/index.js');
    console.log('Filepath from loadscript', filePath)
    try {
        customMethods = require(filePath);
    } catch (error) {
        console.error('Error loading script:', error);
        return [];
    }

    methodNames = Object.keys(customMethods);
    console.log(methodNames)

    return methodNames;
};


export const ExecuteMethod = async (methodName: string, world: TestWorld, ...args: any[]) => {
    if (!methodNames)
        LoadScript();

    if (methodNames.includes(methodName)) {
        await customMethods[methodName](world, ...args);
    } else {
        console.error('Method not found:', methodName);
    }
};