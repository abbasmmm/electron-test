import { IWorldOptions, setDefaultTimeout, setWorldConstructor, World } from '@cucumber/cucumber';
import { Browser, BrowserContext, chromium, Page, PlaywrightTestConfig } from '@playwright/test';
import path from 'path';
import fs from 'fs';
import yaml from 'js-yaml'
import { ComponentLocatorsModel, CustomStorage } from './contracts';
import { ExecuteMethod } from './framework/step-loader';

/** World.
 *  @class
 *  Test World is instantiated on each scenario and shares state between step definitions, this can be a reference
 *  to the browser object, page objects or any custom code - best practice is to create your page objects here
 */
export class TestWorld extends World {
  browser!: Browser;
  context!: BrowserContext;
  page!: Page;
  playwrightConf: PlaywrightTestConfig;
  testSettings!: CustomStorage;
  currentPage!: ComponentLocatorsModel;
  executeStep!: any;

  constructor(opts: IWorldOptions) {
    super(opts);

    this.playwrightConf = {
      use: {
        screenshot: 'only-on-failure',
        headless: this.parameters.headless,
      },
      timeout: 10000,
      snapshotDir: './e2e/results/screenshots',
    };
  }

  /**
   * init: setup browser, context and new page and any page objects
   * this is called from a cucumber Before hook to ensure everything
   * is setup before each set of tests
   */
  async init() {
    const { timeout, use } = this.playwrightConf;

    this.browser = await chromium.launch({ headless: use?.headless, timeout });
    this.context = await this.browser.newContext();
    this.page = await this.context.newPage();

    // await this.page.goto(this.parameters.appUrl);
    await this.page.waitForLoadState('networkidle');

    this.initializeTestSettings();
  }

  initializeTestSettings() {
    const filePath = path.resolve(__dirname, '..', 'test-setup.yml');

    // Read the file synchronously (or asynchronously if preferred)
    // console.log(filePath);
    // Check if the custom-storage.yml file exists
    if (!fs.existsSync(filePath)) {
      console.error('test setup file not found:' + filePath)
    }
    else {
      // Load the YAML file      
      const fileContents = fs.readFileSync(filePath, 'utf8');
      const storage = yaml.load(fileContents) as CustomStorage;

      storage.Steps = {
        '^the user is on the (.+)$': 'Goto',
        '^the user enters (.+) into the (.+)$': 'Fill',
        '^the user clicks the (.+)$': 'Click',
        '^the user should be redirected to the (.+)$': 'VerifyPageLoaded'
      }

      fs.writeFileSync(filePath+ '-', yaml.dump(storage))

      this.testSettings = storage;
    }

    this.executeStep = ExecuteMethod
  }

  /**
   * destroy: close page, browser context and browser.
   * This is usually called from a cucumber After hook
   */
  async destroy() {
    await this.page?.close();
    await this.context?.close();
    await this.browser?.close();
  }
}

setWorldConstructor(TestWorld);
setDefaultTimeout(30000);
