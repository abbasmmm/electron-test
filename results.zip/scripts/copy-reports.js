const shell = require('shelljs');
const path = require('path');

// Get the current date and time to create a unique folder name
const dateTime = new Date().toISOString().replace(/T/, '_').replace(/:/g, '-').replace(/\..+/, '');
const targetDir = path.join(__dirname, '../results', dateTime);

// Create the target directory
shell.mkdir('-p', targetDir);

// List of files to copy
const filesToCopy = [
  'e2e/results/cucumber-report.json',
  'e2e/results/cucumber-report.html',
  'e2e/results/report.html'
];

// Copy each file to the target directory
filesToCopy.forEach((file) => {
  shell.cp(file, targetDir);
});

console.log(`Reports copied to ${targetDir}`);
