import { Fill, Click, VerifyPageLoaded, Goto } from "./framework/generic-steps";

export {Fill, Click, VerifyPageLoaded, Goto}
