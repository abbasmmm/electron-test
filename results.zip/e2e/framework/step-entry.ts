const { defineStep } = require('@cucumber/cucumber');

defineStep(/^(.*)$/, async function (stepText) {

  const keys = Object.keys(this.testSettings.Steps);
  const regexStr = keys.find(x => new RegExp(x, 'i').test(stepText));

  if (!regexStr) {
    console.error(`No matching step definition found for: ${stepText}`);
    return;
  }

  const regex = new RegExp(regexStr, 'i');
  const [, ...params] = stepText.match(regex);

  const stepFunctionName = this.testSettings.Steps[regexStr];

  if (stepFunctionName) {
    //console.log('StepFunction: ' + stepFunctionName);
    await this.executeStep(stepFunctionName, this, ...params);
  } else {
    console.error(`No function found for regex: ${regex}`);
  }
});
