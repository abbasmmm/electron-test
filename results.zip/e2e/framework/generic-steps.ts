import { expect } from 'playwright/test';
import { TestWorld } from '../world';

const cleanString = (str: string) => {
  const trimmed = str.trim();
  const withoutQuotes = trimmed.replace(/^["']|["']$/g, '');
  return withoutQuotes.toLowerCase();
};

const compareStrings = (str1: string, str2: string): boolean => {
  return cleanString(str1) === cleanString(str2);
};

export const Fill = async (world: TestWorld, value: string, locatorName: string) => {
  const locator = world.currentPage.Locators.find(x => compareStrings(x.name, locatorName)).locator;
  await world.page.locator(locator).fill(cleanString(value));
}

export const Click = async (world: TestWorld, locatorName: string) => {
  const locator = world.currentPage.Locators.find(x => compareStrings(x.name, locatorName)).locator;
  await world.page.locator(locator).click();
}

export const VerifyPageLoaded = async (world: TestWorld, page: string) => {
  const pageConfig = world.testSettings.Locators.ComponentLocators.find(x => compareStrings(x.ComponentName, page));
  const element = await world.page.locator(pageConfig.ComponentLocator);
  await expect(element).toBeVisible();
  world.currentPage = pageConfig;
}

export const Goto = async (world: TestWorld, page: string) => {
  const pageConfig = world.testSettings.Locators.ComponentLocators.find(x => compareStrings(x.ComponentName, page));
  await world.page.goto(pageConfig.Url);
  world.currentPage = pageConfig;
}
